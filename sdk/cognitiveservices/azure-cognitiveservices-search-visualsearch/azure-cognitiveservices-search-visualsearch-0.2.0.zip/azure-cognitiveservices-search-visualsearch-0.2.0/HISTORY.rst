.. :changelog:

Release History
===============

0.2.0 (2018-12-11)
++++++++++++++++++

**Features**

- New parameters market, safe_search and set_lang

0.1.1 (2018-05-04)
++++++++++++++++++

**Bugfixes**

- Fix knowledge_request parameter (was ignored by the SDK)

0.1.0 (2018-05-02)
++++++++++++++++++

* Initial Release
